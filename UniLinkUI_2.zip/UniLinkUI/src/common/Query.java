package common;

public class Query{
    public static String getUser = "select * from user where name = ''";
}
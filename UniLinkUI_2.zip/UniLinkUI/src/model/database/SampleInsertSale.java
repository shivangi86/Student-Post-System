package model.database;

import model.database.ConnectionTest;

import java.sql.Connection;
import java.sql.Statement;

public class SampleInsertSale {
    public static void main(String[] args) {
        final String DB_NAME = "testDB";
        final String TABLE_NAME = "POST";

        //use try-with-resources Statement
        try (Connection con = ConnectionTest.getConnection(DB_NAME);
             Statement stmt = con.createStatement();
        ) {
            String query = "INSERT INTO " + TABLE_NAME +
                    " VALUES ('SAL001', 'SALE', 'iPhone 6s', 'iPhone 6 sale', 'jack123', 'OPEN')," +
                    "        ('SAL002', 'SALE', 'iPad', 'iPad Sale', 'john123', 'OPEN')";
            //" VALUES (2, 's3089940', 'Tom', 'Bruster')";
            con.commit();

            int result = stmt.executeUpdate(query);

            String querySale = "INSERT INTO SALE" +
                    " VALUES ('SAL001', 100.5, 50.5, 20.5, 'image1.png')," +
                    "        ('SAL002', 200, 40, 15, 'image2.png')";
            //" VALUES (2, 's3089940', 'Tom', 'Bruster')";

            int result1 = stmt.executeUpdate(querySale);
            con.commit();


            System.out.println("Insert into table " + TABLE_NAME + " executed successfully");
            System.out.println(result + " row(s) affected");

        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}

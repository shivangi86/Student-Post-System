package model.database;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectQuery {
    public static void main(String[] args) {
        final String DB_NAME = "testDB";
        final String TABLE_NAME = "POST";

    }

    private ResultSet executeSelect(Connection conn, String query) {
        //use try-with-resources Statement
//        try (Connection con = ConnectionTest.getConnection(DB_NAME);
//        )
//        try
//        {
//        String query = "SELECT * FROM " + TABLE_NAME;
//            String query1 = "SELECT * FROM user";

            try {
                Statement stmt = conn.createStatement();
                ResultSet resultSet = stmt.executeQuery(query);
                if(!resultSet.next() == false  ){
                    return null;
                }
                else{
                    System.out.println("not empty");
                    return resultSet;
//                    while(resultSet.next()) {
//                        System.out.printf("Id: %d | Post Number: %s | Post Type: %s | Post Details: %s\n",
//                                resultSet.getInt("id"), resultSet.getString("post_number"),
//                                resultSet.getString("type"), resultSet.getString("details"));
//                    }
                }

            } catch (SQLException e) {
                System.out.println(e.getMessage());
                return null;
            }

//        } catch (Exception e) {
//            System.out.println(e.getMessage());
//        }
    }
}
